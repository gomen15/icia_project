package com.example.demo.exception;
//
public class CommonException extends RuntimeException {
	public CommonException(String msg) {
		super(msg); 
	}
}
